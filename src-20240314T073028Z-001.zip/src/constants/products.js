export const allProducts = [
  {
    id: 1,
    name: "Laptop",
    category: "Electronics",
    price: 66200,
    stock: 50,
  },
  {
    id: 2,
    name: "Samsung Mobile",
    category: "Electronics",
    price: 18000,
    stock: 30,
  },
  {
    id: 3,
    name: "Shirt",
    category: "Clothing",
    price: 900,
    stock: 70,
  },
  {
    id: 4,
    name: "Sofa",
    category: "Household",
    price: 12000,
    stock: 25,
  },
];
